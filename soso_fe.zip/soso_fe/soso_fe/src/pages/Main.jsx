import React from 'react'
import { Layout } from '../components/element'

function Main() {
  return (
    <Layout>Main</Layout>
  )
}

export default Main
